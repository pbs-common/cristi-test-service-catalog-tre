import hcl2
import json

# Read the variables.tf file
with open("my_variables.tf", "r") as tf_file:
    tf_content = hcl2.load(tf_file)

# Debug: Print the parsed content
print(json.dumps(tf_content, indent=4))

# Extract variables and their default values
variables = {}

# Iterate through the list of variables
if "variable" in tf_content:
    for variable in tf_content["variable"]:
        # Each variable is a dictionary with one key (the variable name)
        for var_name, var_data in variable.items():
            # Extract the default value, or set to None if not defined
            variables[var_name] = var_data.get("default", None)

# Write to a JSON file
with open("variables.json", "w") as json_file:
    json.dump(variables, json_file, indent=4)

print("Converted my_variables.tf to variables.json")